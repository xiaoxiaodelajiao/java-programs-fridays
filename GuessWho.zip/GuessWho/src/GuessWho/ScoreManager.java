package GuessWho;

public class ScoreManager {
    
}
