package GuessWho;

enum enumEyeColor {
    BROWN,
    BLUE,
    NOTSET;
}
