package GuessWho;

enum enumHairColor {
    YELLOW,
    BLACK,
    WHITE,
    ORANGE,
    BROWN,
    NOTSET;
}