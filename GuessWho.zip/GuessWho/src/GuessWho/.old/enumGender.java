package GuessWho;

enum enumGender {
    MALE,
    FEMALE,
    NOTSET;
}
