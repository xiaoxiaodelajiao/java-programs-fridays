package GuessWho;

enum enumFacialHair {
    MUSTACHE,
    BEARD,
    MUSTACHE_AND_BEARD,
    NOTSET;
}
