package GuessWho;

enum enumBlush {
    HAS_BLUSH,
    NO_BLUSH,
    NOTSET;
}