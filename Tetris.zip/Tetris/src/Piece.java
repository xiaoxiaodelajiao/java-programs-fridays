public abstract class Piece {
    Point[] points;
    int orientation;
    
    public Piece() {
        points = new Point[4];
        orientation = 0;
    }

    public void rotate() {
        for(Point point : points) {
            Game.board[point.y][point.x] = ' ';
        }
        rotateHelper();
        for(Point point : points) {
            if(Game.board[point.y][point.x] == 'X') {
                rotateHelper();
                rotateHelper();
                rotateHelper();
                break;
            }
        }
    }
    
    public void moveLeft() {
        for(Point point : points) {
            if(point.x == 0 || Game.board[point.y][point.x-1] == 'X') return;
        }
        //TODO can't collide with other pieces
        for(Point point : points) {
            Game.board[point.y][point.x] = ' ';
            point.x --;
        }
    }
    public void moveRight() {
        for(Point point : points) {
            if(point.x == 9 || Game.board[point.y][point.x+1] == 'X') return;
        }
        //TODO can't collide with other pieces
        for(Point point : points) {
            Game.board[point.y][point.x] = ' ';
            point.x ++;
        }
    }
    public  void moveDown() {
        for(Point point : points) {
            if(point.y == 19 || Game.board[point.y+1][point.x] == 'X') return;
        }
        //TODO can't collide with other pieces
        for(Point point : points) {
            Game.board[point.y][point.x] = ' ';
            point.y ++;
        }
    }
    public void moveDrop() {
        while(true) {
            for(Point point : points) {
                if(point.y == 19 || Game.board[point.y+1][point.x] == 'X') return;
            }
            for(Point point : points) {
                Game.board[point.y][point.x] = ' ';
                point.y ++;
            }
        }
    }
    public boolean isColliding() {
        for(Point point : points) {
            if(Game.board[point.y][point.x] == 'X') {
                return true;
            }
        }
        return false;
    }

    protected abstract void rotateHelper();
}
