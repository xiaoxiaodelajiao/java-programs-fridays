import java.io.*;
import java.util.*;

public class Game {
    Input input;
    static char[][] board = new char[20][10];
    BufferedOutputStream buffer;
    Piece activePiece;
    Random random = new Random();
    int gameState = 0;

    public Game() {
        input = new Input(this);
        buffer = new BufferedOutputStream(System.out);
        for(int i = 0; i < board.length; i ++) {
            for(int j = 0; j < board[i].length; j ++) {
                board[i][j] = ' ';
            }
        }

    }

    public void checkLines() {
        boolean flag = false;
        for(int i = 0; i < 20; i ++) {
            flag = true;
            for(int j = 0; j < 10 && flag; j ++) {
                if(board[i][j] != 'X') flag = false;
            }
            if(flag) {
                for(int k = i; k > 0; k --) {
                    for(int j = 0; j < 10; j ++) {
                        board[k][j] = board[k-1][j];
                    }
                }
                i--;
            }
        }
    }

    public void printBoard() throws IOException {
        if(gameState == 1) return;

        for(Point point : activePiece.points) {
            board[point.y][point.x] = 'O';
        }
        
        for(int i = 0; i < board[0].length+2; i ++){
            buffer.write('_');
        }
        buffer.write('\n');
        for(int i = 0; i < board.length; i ++) {
            buffer.write('|');
            for(int j = 0; j < board[i].length; j ++) {
                buffer.write(board[i][j]);
            }
            buffer.write('|');
            buffer.write('\n');
        }
        for(int i = 0; i < board[0].length+2; i ++){
            buffer.write('_');
        }
        buffer.write('\n');
        buffer.flush();
    }

    public Piece getPiece() {
        int pieceNum = random.nextInt(5);
        if(pieceNum == 0) return new IPiece();
        else if(pieceNum == 1) return new OPiece();
        else if(pieceNum == 2) return new SPiece();
        else if(pieceNum == 3) return new TPiece();
        else return new ZPiece();

    }

    public void start() throws Exception{
        activePiece = getPiece();
        while(true) {
            
            

            printBoard();
            Thread.sleep(1000);

            for(Point point : activePiece.points) {
                if(point.y+1 == board.length || board[point.y+1][point.x] == 'X') {
                    for(Point p : activePiece.points) {
                        board[p.y][p.x] = 'X';
                    }
                    activePiece = getPiece();
                    if(activePiece.isColliding()){
                        System.out.println("Game over");    
                        gameState = 1;
                        return;
                    }
                    break;
                }
            }
            activePiece.moveDown();
            checkLines();
            
        }
    }

    public void keyPressed(int key) {
        if(gameState == 1) return;
        if(key == Input.UP) {
            activePiece.rotate();
        }
        else if(key == Input.DOWN) {
            activePiece.moveDown();
        }
        else if(key == Input.LEFT) {
            activePiece.moveLeft();
        }
        else if(key == Input.RIGHT) {
            activePiece.moveRight();
        }
        else if(key == Input.SPACE) {
            activePiece.moveDrop();
        }
        try {
            printBoard();
        }
        catch(Exception e) {
            
        }
    }
}
