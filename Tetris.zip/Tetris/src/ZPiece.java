public class ZPiece extends Piece{
    
    public ZPiece() {
        super();
        points[0] = new Point(4, 0);
        points[1] = new Point(5, 0);
        points[2] = new Point(5, 1);
        points[3] = new Point(6, 1);
    }

    protected void rotateHelper() {
        if(orientation == 0 || orientation == 2) {
            points[0].x += 2;
            points[0].y --;
            points[1].x ++;
            points[2].y --;
            points[3].x --;
            orientation ++;
            orientation = orientation % 4;
        }
        else if(points[2].x > 0) {
            points[0].x -= 2;
            points[0].y ++;
            points[1].x --;
            points[2].y ++;
            points[3].x ++;
            orientation ++;
            orientation = orientation % 4;
        }
    }
}
