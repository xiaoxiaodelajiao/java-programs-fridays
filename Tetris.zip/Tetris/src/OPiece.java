public class OPiece extends Piece{
    
    public OPiece() {
        super();
        points[0] = new Point(4, 0);
        points[1] = new Point(5, 0);
        points[2] = new Point(4, 1);
        points[3] = new Point(5, 1);
    }

    protected void rotateHelper() { }
}