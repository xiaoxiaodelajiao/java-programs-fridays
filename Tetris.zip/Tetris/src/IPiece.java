public class IPiece extends Piece{
    
    public IPiece() {
        super();
        points[0] = new Point(3, 0);
        points[1] = new Point(4, 0);
        points[2] = new Point(5, 0);
        points[3] = new Point(6, 0);
    }

    protected void rotateHelper() {
        if(orientation == 0 || orientation == 2) {
            points[0].x ++;
            points[0].y += 2;
            points[1].y ++;
            points[2].x --;
            points[3].x -= 2;
            points[3].y --;
            orientation ++;
            orientation = orientation % 4;
        }
        else if(points[2].x < 8 && points[2].x > 0) {
            points[0].x --;
            points[0].y -= 2;
            points[1].y --;
            points[2].x ++;
            points[3].x += 2;
            points[3].y ++;
            orientation ++;
            orientation = orientation % 4;
        }
    }
}