import java.awt.event.*;
import javax.swing.*;

public class Input extends JFrame implements KeyListener {
    Game game;
    static int UP = 0;
    static int DOWN = 1;
    static int LEFT = 2;
    static int RIGHT = 3;
    static int SPACE = 4;

    public Input(Game game) {
        addKeyListener(this);
        setSize(100,100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        this.game = game;
    }

    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_UP){
            game.keyPressed(UP);
        } else if(e.getKeyCode() == KeyEvent.VK_DOWN) {
            game.keyPressed(DOWN);
        } else if(e.getKeyCode() == KeyEvent.VK_LEFT) {
            game.keyPressed(LEFT);
        } else if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
            game.keyPressed(RIGHT);
        } else if(e.getKeyCode() == KeyEvent.VK_SPACE) {
            game.keyPressed(SPACE);
        }
    }

    public void keyReleased(KeyEvent e) {

    }

    public void keyTyped(KeyEvent e) {

    }
    
}
