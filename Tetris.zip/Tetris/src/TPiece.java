public class TPiece extends Piece{
    
    public TPiece() {
        super();
        points[0] = new Point(4, 1);
        points[1] = new Point(5, 0);
        points[2] = new Point(5, 1);
        points[3] = new Point(6, 1);
    }

    protected void rotateHelper() {
        if(orientation == 0 && points[0].y < 19) {
            points[0].x ++;
            points[0].y ++;
            orientation ++;
            orientation = orientation % 4;
        }
        else if(orientation == 1 && points[2].x > 0) {
            points[1].x --;
            points[1].y ++;
            orientation ++;
            orientation = orientation % 4;
        }
        else if(orientation == 2) {
            points[3].x --;
            points[3].y --;
            orientation ++;
            orientation = orientation % 4;
        }
        else if(orientation == 3 && points[2].x < 9) {
            points[0].x --;
            points[0].y --;
            points[1].x ++;
            points[1].y --;
            points[3].x ++;
            points[3].y ++;
            orientation ++;
            orientation = orientation % 4;
        }
        
    }
}