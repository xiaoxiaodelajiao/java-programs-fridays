public class SPiece extends Piece{
    
    public SPiece() {
        super();
        points[0] = new Point(6, 0);
        points[1] = new Point(5, 0);
        points[2] = new Point(5, 1);
        points[3] = new Point(4, 1);
    }

    protected void rotateHelper() {
        if(orientation == 0 || orientation == 2 ) {
            points[0].x -= 2;
            points[0].y --;
            points[1].x --;
            points[2].y --;
            points[3].x ++;
            orientation ++;
            orientation = orientation % 4;
        }
        else if(points[2].x < 9) {
            points[0].x += 2;
            points[0].y ++;
            points[1].x ++;
            points[2].y ++;
            points[3].x --;
            orientation ++;
            orientation = orientation % 4;
        }
    }
}
